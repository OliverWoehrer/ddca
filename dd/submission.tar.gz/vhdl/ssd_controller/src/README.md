# TASK 2 and 7:
Put your code for the ssd_controller here (ssd_controller.vhd)
Remember: Thou shalt not use the ALL keyword for sensitivity lists (in this file)

# TASK 7:
Put your code for the ssd_controller testbench here (ssd_controller_tb.vhd)

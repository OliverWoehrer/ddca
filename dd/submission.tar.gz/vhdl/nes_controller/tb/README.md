# TASK 6:
Put your code for the nes_controller testbench here (nes_controller_tb.vhd)

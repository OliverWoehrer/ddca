# TASK 6:
Put your code for the nes_controller here (nes_controller.vhd)

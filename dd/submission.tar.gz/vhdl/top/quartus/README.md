#Task 1:
place your quartus procject (top.qsf/top.qpf) here
your sdc file also goes here
